// Declare interface and methods but contains no "body"
public interface Splittable {
    public int size(); // method
    public Splittable firstHalf(); // method
    public Splittable secondHalf(); // method
}
