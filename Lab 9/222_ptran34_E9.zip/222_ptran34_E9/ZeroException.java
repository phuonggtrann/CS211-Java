// Declare Exception class
public class ZeroException extends Exception {
    public ZeroException() {
        super(); // Super() bc this is a children class
    }
}