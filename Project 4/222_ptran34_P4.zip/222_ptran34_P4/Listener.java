public interface Listener<type1, type2> {
    public void signal(type1 t1, type2 t2);
}