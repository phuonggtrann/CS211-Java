// Declare interface
public interface DeviceInfo{
    // Needed methods
    public String name(); 
    public int id();
}