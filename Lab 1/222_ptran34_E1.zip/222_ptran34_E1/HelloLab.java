public class HelloLab {
  public static void main(String[] args) {
    System.out.print("Hello CS Lab!\n");
  }}