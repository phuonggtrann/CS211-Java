public class CSWisdom {
  public static void main(String[] args) {
    System.out.println("The most damaging phrase in the language is:");
    System.out.println("We've always done it this way!\n");
    ///System.out.println("");
    System.out.println("- Admiral Grace Hopper");
  }}