public interface Player {
  public boolean canPlay(Loadable l);
  public void play(Loadable l);
}