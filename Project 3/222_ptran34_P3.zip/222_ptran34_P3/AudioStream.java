public interface AudioStream {
  public int freq();
  public int next();
  public boolean hasNext();
}