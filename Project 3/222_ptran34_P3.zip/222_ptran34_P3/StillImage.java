public interface StillImage {
  public int width();
  public int height();
  public int getPixel(int x, int y); 
}