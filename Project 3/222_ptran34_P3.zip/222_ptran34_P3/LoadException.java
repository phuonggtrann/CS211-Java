// an Exception
public class LoadException extends Exception { // Declare exception class
    public LoadException(String msg) {
        super(msg);
    }
}